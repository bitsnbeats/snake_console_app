In order to get Snake to display properly, please do the following:

1) Open Command Prompt. You can search for Command Prompt using the Windows search bar in the bottom left corner
   of your desktop.

2) Right click on the top border of you Command Prompt window. A menu box should pop up.

3) From the menu, click defaults. This will open another menu box.

4) On the Layout tab, set your Window Size to 120 (width) by 30 (height).
	4b) You can also change the font of the Command Prompt characters by choosing the Font tab and selecting
	    a size from the drop-down menu. This will affect the scale your game renders at.

5) Exit Command Prompt.

You are now ready to play Snake! Double click on the Snake.exe file to start.

